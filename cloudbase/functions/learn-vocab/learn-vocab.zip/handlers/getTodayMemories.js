/**
 * 统一获取今日学习内容 (字母/单词/句子)
 * Action: getTodayMemories
 */

const { getTodayReviewEntities, getOrCreateMemory, checkModuleAccess } = require('../utils/memoryEngine');
const { validateParams } = require('../utils/validators');
const { createResponse } = require('../utils/response');

/**
 * @param {Object} db - 数据库实例
 * @param {Object} params - 请求参数
 * @param {string} params.userId - 用户ID
 * @param {string} params.entityType - 实体类型: 'letter' | 'word' | 'sentence'
 * @param {number} [params.limit=20] - 返回数量
 * @param {boolean} [params.includeNew=true] - 是否包含新内容
 */
async function getTodayMemories(db, params) {
  // 1. 参数验证
  const validation = validateParams(params, ['userId', 'entityType']);
  if (!validation.isValid) {
    return createResponse(false, null, validation.message, 'INVALID_PARAMS');
  }

  const { userId, entityType, limit = 20, includeNew = true } = params;

  // 检查用户是否完成字母学习
  const progress = await db
    .collection("user_progress")
    .where({ userId })
    .get();

  const p = progress.data[0];

  if (!p.wordUnlocked) {
    return {
      code: 403,
      msg: "请先完成字母学习 \n Please complete the letter learning first"
    };
  }

  // 2. 检查模块访问权限
  const accessCheck = await checkModuleAccess(db, userId, entityType);
  if (!accessCheck.allowed) {
    return createResponse(false, null, accessCheck.message, accessCheck.errorCode);
  }

  try {
    // 3. 获取今日需要复习的实体
    const reviewMemories = await getTodayReviewEntities(db, userId, entityType, limit);

    // 4. 获取新学习内容(如果需要)
    let newMemories = [];
    if (includeNew && reviewMemories.length < limit) {
      const remainingSlots = limit - reviewMemories.length;

      // 根据实体类型查询对应的内容表
      const collectionMap = {
        letter: 'letters',
        word: 'vocabularies',
        sentence: 'sentences'
      };

      const collection = collectionMap[entityType];
      if (!collection) {
        return createResponse(false, null, `不支持的实体类型: ${entityType}`, 'INVALID_ENTITY_TYPE');
      }

      // 查询尚未学习的实体
      const existingEntityIds = reviewMemories.map(m => m.entityId);
      const newEntitiesResult = await db.collection(collection)
        .limit(remainingSlots)
        .get();

      // 过滤出未学习的
      const newEntities = newEntitiesResult.data.filter(entity => {
        const entityId = entity._id;
        return !existingEntityIds.includes(entityId);
      });

      // 为新实体创建记忆记录
      for (const entity of newEntities) {
        const memory = await getOrCreateMemory(
          db,
          userId,
          entityType,
          entity._id,
          false // 不锁定
        );
        newMemories.push(memory);
      }
    }

    // 5. 合并复习和新学习内容
    const allMemories = [...reviewMemories, ...newMemories];

    // 6. 获取实体详情
    const entityIds = allMemories.map(m => m.entityId);
    const collectionMap = {
      letter: 'letters',
      word: 'vocabularies',
      sentence: 'sentences'
    };

    const entitiesResult = await db.collection(collectionMap[entityType])
      .where({
        _id: db.command.in(entityIds)
      })
      .get();

    // 7. 组装返回数据
    const data = entitiesResult.data.map(entity => {
      const memory = allMemories.find(m => m.entityId === entity._id);
      return {
        ...entity,
        memoryState: {
          masteryLevel: memory.masteryLevel,
          reviewStage: memory.reviewStage,
          correctCount: memory.correctCount,
          wrongCount: memory.wrongCount,
          streakCorrect: memory.streakCorrect,
          nextReviewAt: memory.nextReviewAt,
          isNew: memory.reviewStage === 0
        }
      };
    });

    // 8. 统计信息
    const summary = {
      total: data.length,
      reviewCount: reviewMemories.length,
      newCount: newMemories.length,
      entityType
    };

    return createResponse(true, {
      items: data,
      summary
    }, '获取今日学习内容成功');

  } catch (error) {
    console.error('getTodayMemories 错误:', error);
    return createResponse(false, null, error.message || '服务器错误', 'SERVER_ERROR');
  }
}

module.exports = getTodayMemories;