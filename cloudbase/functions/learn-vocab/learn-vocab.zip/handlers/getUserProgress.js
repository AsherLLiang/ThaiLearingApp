/**
 * 获取用户学习进度
 * Action: getUserProgress
 */

const { validateParams } = require('../utils/validators');
const { createResponse } = require('../utils/response');

/**
 * @param {Object} db - 数据库实例
 * @param {Object} params - 请求参数
 * @param {string} params.userId - 用户ID
 */
async function getUserProgress(db, params) {
  // 1. 参数验证
  const validation = validateParams(params, ['userId']);
  if (!validation.isValid) {
    return createResponse(false, null, validation.message, 'INVALID_PARAMS');
  }

  const { userId } = params;

  try {
    // 2. 获取用户进度记录
    const progressResult = await db.collection('user_progress')
      .where({ userId })
      .getOne();

    if (!progressResult.data) {
      return createResponse(false, null, '用户进度记录不存在', 'USER_PROGRESS_NOT_FOUND');
    }

    const progress = progressResult.data;

    // 3. 统计各模块学习数据
    const letterStats = await db.collection('memory_status')
      .where({
        userId,
        entityType: 'letter'
      })
      .get();

    const wordStats = await db.collection('memory_status')
      .where({
        userId,
        entityType: 'word'
      })
      .get();

    // 4. 计算统计数据
    const letterMastered = letterStats.data.filter(m => m.masteryLevel >= 0.7).length;
    const wordMastered = wordStats.data.filter(m => m.masteryLevel >= 0.7).length;

    // 5. 组装返回数据
    const result = {
      ...progress,
      statistics: {
        letter: {
          total: 44, // 泰语字母总数
          learned: letterStats.data.length,
          mastered: letterMastered,
          progress: letterStats.data.length > 0 ? (letterMastered / 44).toFixed(2) : 0
        },
        word: {
          total: 3500, // 假设总单词数
          learned: wordStats.data.length,
          mastered: wordMastered,
          progress: wordStats.data.length > 0 ? (wordMastered / 3500).toFixed(2) : 0
        }
      },
      unlockStatus: {
        letter: true,
        word: progress.wordUnlocked,
        sentence: progress.sentenceUnlocked,
        article: progress.articleUnlocked
      }
    };

    return createResponse(true, result, '获取用户进度成功');

  } catch (error) {
    console.error('getUserProgress 错误:', error);
    return createResponse(false, null, error.message || '服务器错误', 'SERVER_ERROR');
  }
}

module.exports = getUserProgress;